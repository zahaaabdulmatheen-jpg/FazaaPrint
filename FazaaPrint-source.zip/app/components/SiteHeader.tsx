"use client";

import { usePathname } from "next/navigation";

const links = [
  ["Home", "/"],
  ["Services & Prices", "/services"],
  ["Past Papers", "/past-papers"],
  ["Contact", "/contact"],
] as const;

export default function SiteHeader() {
  const pathname = usePathname();
  return <header className="site-header">
    <a className="brand logo-brand" href="/" aria-label="FazaaPrint home"><img src="/fazaaprint-logo.png" alt="FazaaPrint" /></a>
    <nav aria-label="Main navigation">{links.map(([label, href]) => <a className={pathname === href ? "nav-active" : ""} href={href} key={href}>{label}</a>)}</nav>
    <a className="cart-button" href="/order"><span>Order online</span><b>→</b></a>
  </header>;
}
