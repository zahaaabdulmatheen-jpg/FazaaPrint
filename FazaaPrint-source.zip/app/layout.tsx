import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FazaaPrint — Printing made simple",
  description: "Order A4 printing, past papers, binding, laminating and more from FazaaPrint in the Maldives.",
  openGraph: {
    title: "FazaaPrint — Your ideas, beautifully printed",
    description: "Clear prices, smart color estimates and easy print ordering in the Maldives.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FazaaPrint — Your ideas, beautifully printed",
    description: "Printing made simple in the Maldives.",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
