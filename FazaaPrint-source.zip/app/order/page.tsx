"use client";

import { ChangeEvent, useMemo, useRef, useState } from "react";
import SiteHeader from "../components/SiteHeader";

type CoveragePage = { name: string; coverage: number; price: number; preview?: string };
type CartItem = { id: number; title: string; detail: string; price: number };

const services = [
  ["Binding", 20, "A tidy, durable finish"],
  ["Scanning", 10, "Clear digital copies"],
  ["Worksheet Program", 150, "Ready-to-use learning packs"],
  ["Book Cover Design & Printing", 45, "Designed and printed for you"],
  ["Book Cover", 50, "Protective cover finish"],
  ["Cellophane", 100, "Neat protective wrapping"],
  ["Staples", 4, "Secure document finishing"],
  ["Laminate", 15, "Long-lasting protection"],
] as const;

const papers = [
  ["English Past Paper", 380, "English", "EN"],
  ["Economics Past Paper", 150, "Economics", "EC"],
  ["Chemistry Past Paper", 530, "Chemistry", "CH"],
  ["Biology Past Paper", 600, "Biology", "BI"],
] as const;

const money = (value: number) => `MVR ${value.toFixed(value % 1 ? 2 : 0)}`;

function Icon({ name }: { name: "arrow" | "upload" | "check" | "bag" | "phone" | "spark" }) {
  const icons = { arrow: "â†’", upload: "â‡§", check: "âœ“", bag: "â–¢", phone: "â—–", spark: "âœ¦" };
  return <span aria-hidden="true">{icons[name]}</span>;
}

export default function Home() {
  const [mode, setMode] = useState<"bw" | "color">("bw");
  const [sides, setSides] = useState<1 | 2>(1);
  const [pages, setPages] = useState(1);
  const [copies, setCopies] = useState(1);
  const [binding, setBinding] = useState(false);
  const [laminate, setLaminate] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [coveragePages, setCoveragePages] = useState<CoveragePage[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const avgCoverage = coveragePages.length
    ? coveragePages.reduce((sum, page) => sum + page.coverage, 0) / coveragePages.length
    : 100;
  const printPrice = mode === "bw"
    ? pages * copies * sides * 2
    : pages * copies * sides * 35 * (avgCoverage / 100);
  const extrasPrice = (binding ? 20 : 0) + (laminate ? 15 * pages * copies : 0) + (scanning ? 10 : 0);
  const orderTotal = printPrice + extrasPrice;
  const cartTotal = useMemo(() => cart.reduce((sum, item) => sum + item.price, 0), [cart]);

  function addCart(title: string, detail: string, price: number) {
    setCart((current) => [...current, { id: Date.now() + Math.random(), title, detail, price }]);
    setToast(`${title} added to your order`);
    window.setTimeout(() => setToast(""), 2400);
  }

  function addPrintOrder() {
    addCart(
      `${mode === "bw" ? "B&W" : "Color"} A4 printing`,
      `${pages} page${pages !== 1 ? "s" : ""} Â· ${sides === 2 ? "Double-sided" : "Single-sided"} Â· ${copies} ${copies === 1 ? "copy" : "copies"}${binding ? " Â· Binding" : ""}${laminate ? " Â· Laminate" : ""}${scanning ? " Â· Scan" : ""}`,
      orderTotal,
    );
  }

  async function analyzeFiles(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;
    setIsAnalyzing(true);
    const results: CoveragePage[] = [];
    for (const file of files) {
      if (file.type.startsWith("image/")) {
        const preview = URL.createObjectURL(file);
        const img = new Image();
        img.src = preview;
        await img.decode();
        const canvas = document.createElement("canvas");
        const scale = Math.min(1, 700 / Math.max(img.width, img.height));
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
        const data = ctx?.getImageData(0, 0, canvas.width, canvas.height).data;
        let ink = 0;
        if (data) {
          for (let i = 0; i < data.length; i += 16) {
            const whiteDistance = (255 - data[i]) + (255 - data[i + 1]) + (255 - data[i + 2]);
            const chroma = Math.max(data[i], data[i + 1], data[i + 2]) - Math.min(data[i], data[i + 1], data[i + 2]);
            ink += Math.min(1, whiteDistance / 360) * (0.72 + Math.min(chroma / 160, 0.28));
          }
          const samples = Math.ceil(data.length / 16);
          const coverage = Math.max(1, Math.min(100, (ink / samples) * 100));
          results.push({ name: file.name, coverage, price: coverage * 0.35, preview });
        }
      } else if (file.type === "application/pdf") {
        const text = new TextDecoder("latin1").decode(await file.arrayBuffer());
        const detected = Math.max(1, Math.min(100, (text.match(/\/Type\s*\/Page\b/g) || []).length || pages));
        for (let i = 1; i <= detected; i++) {
          results.push({ name: `${file.name} Â· page ${i}`, coverage: 30, price: 10.5 });
        }
      }
    }
    if (results.length) {
      setCoveragePages(results);
      setPages(results.length);
      setMode("color");
    }
    setIsAnalyzing(false);
  }

  return (
    <main>
      <SiteHeader />


      <section className="section order-section" id="order">
        <div className="section-heading"><span className="eyebrow">Dedicated ordering platform</span><h2>Build your print order</h2><p>Choose your setup and watch your estimated total update instantly.</p></div>
        <div className="order-layout">
          <div className="config-card">
            <div className="step"><span>01</span><div><h3>How should we print it?</h3><div className="toggle-grid"><button className={mode === "bw" ? "active" : ""} onClick={() => setMode("bw")}><b>B&W</b><small>MVR 2 / printed side</small></button><button className={mode === "color" ? "active" : ""} onClick={() => setMode("color")}><b>Color</b><small>Up to MVR 35 / side</small></button></div></div></div>
            <div className="step"><span>02</span><div><h3>Print setup</h3><div className="form-grid"><label>Sides<select value={sides} onChange={(e) => setSides(Number(e.target.value) as 1 | 2)}><option value="1">Single-sided</option><option value="2">Double-sided</option></select></label><label>Page count<input type="number" min="1" value={pages} onChange={(e) => setPages(Math.max(1, Number(e.target.value)))} /></label><label>Copies<input type="number" min="1" value={copies} onChange={(e) => setCopies(Math.max(1, Number(e.target.value)))} /></label></div></div></div>
            <div className="step"><span>03</span><div><h3>Add finishing</h3><div className="check-grid"><label><input type="checkbox" checked={binding} onChange={(e) => setBinding(e.target.checked)} /><span><b>Binding</b><small>+ MVR 20</small></span></label><label><input type="checkbox" checked={laminate} onChange={(e) => setLaminate(e.target.checked)} /><span><b>Laminate</b><small>+ MVR 15 / page</small></span></label><label><input type="checkbox" checked={scanning} onChange={(e) => setScanning(e.target.checked)} /><span><b>Scanning</b><small>+ MVR 10</small></span></label></div></div></div>
            <div className="step upload-step"><span>04</span><div><h3>Upload your files</h3><button className="upload-box" onClick={() => inputRef.current?.click()}><Icon name="upload" /><b>{isAnalyzing ? "Analyzing your pagesâ€¦" : "Choose PDF or page images"}</b><small>Images are analyzed on this device. PDF page count is detected automatically.</small></button><input ref={inputRef} hidden type="file" accept="application/pdf,image/*" multiple onChange={analyzeFiles} /></div></div>
          </div>
          <aside className="summary-card"><div className="summary-top"><span>Live estimate</span><b>{mode === "color" ? `${avgCoverage.toFixed(0)}% avg. coverage` : "Fixed B&W price"}</b></div><div className="summary-price"><small>Estimated total</small><strong>{money(orderTotal)}</strong><span>for {copies} {copies === 1 ? "copy" : "copies"}</span></div><div className="summary-lines"><div><span>{mode === "bw" ? "B&W printing" : "Color printing"}</span><b>{money(printPrice)}</b></div>{binding && <div><span>Binding</span><b>MVR 20</b></div>}{laminate && <div><span>Laminate</span><b>{money(15 * pages * copies)}</b></div>}{scanning && <div><span>Scanning</span><b>MVR 10</b></div>}</div><div className="formula"><b>How we calculated this</b><p>{mode === "bw" ? `${pages} pages Ã— ${sides} side${sides > 1 ? "s" : ""} Ã— ${copies} ${copies === 1 ? "copy" : "copies"} Ã— MVR 2` : `${pages} pages Ã— ${sides} side${sides > 1 ? "s" : ""} Ã— ${copies} ${copies === 1 ? "copy" : "copies"} Ã— MVR 35 Ã— ${avgCoverage.toFixed(0)}% coverage`}</p></div><button className="primary-button full" onClick={addPrintOrder}>Add to order <Icon name="arrow" /></button><small className="estimate-note">Final color price is confirmed by FazaaPrint after reviewing your file.</small></aside>
        </div>
        {mode === "color" && coveragePages.length > 0 && <div className="coverage-card"><div><span className="eyebrow">Color coverage estimate</span><h3>Page-by-page breakdown</h3><p>White areas are not counted as ink. We sample each image locally to estimate visible color/toner coverage.</p></div><div className="coverage-list">{coveragePages.map((page, index) => <div className="coverage-row" key={`${page.name}-${index}`}>{page.preview ? <img src={page.preview} alt="" /> : <span className="pdf-thumb">PDF</span>}<div><b>Page {index + 1}</b><small>{page.name}</small></div><div className="coverage-meter"><i style={{ width: `${page.coverage}%` }} /></div><strong>{page.coverage.toFixed(1)}%</strong><b>{money(page.price * sides * copies)}</b></div>)}</div><div className="coverage-disclaimer"><Icon name="spark" /><p><b>This is an estimate, not a final charge.</b> Screens, printers, paper and image profiles affect actual ink use. PDF pages use a temporary 30% estimate unless uploaded as images; FazaaPrint will confirm your final price before printing.</p></div></div>}
      </section>




      <footer><a className="brand logo-brand" href="/"><img src="/fazaaprint-logo.png" alt="FazaaPrint" /></a><p>Made for bright ideas and busy students.</p><span>© 2026 FazaaPrint · Maldives</span></footer>

      <button className="float-whatsapp" aria-label="Contact FazaaPrint" onClick={() => { window.location.href = "/contact"; }}><Icon name="phone" /></button>
      {toast && <div className="toast"><Icon name="check" /> {toast}</div>}
      {cartOpen && <div className="cart-overlay" onMouseDown={(e) => e.target === e.currentTarget && setCartOpen(false)}><aside className="cart-drawer"><div className="cart-head"><div><span className="eyebrow">Your order</span><h2>Order summary</h2></div><button onClick={() => setCartOpen(false)} aria-label="Close order summary">Ã—</button></div>{cart.length === 0 ? <div className="empty-cart"><span>â–¢</span><h3>Your order is empty</h3><p>Build a print order or add a service to get started.</p><button className="primary-button" onClick={() => setCartOpen(false)}>Start choosing</button></div> : <><div className="cart-items">{cart.map((item) => <article key={item.id}><div><h3>{item.title}</h3><p>{item.detail}</p></div><strong>{money(item.price)}</strong><button onClick={() => setCart((items) => items.filter((candidate) => candidate.id !== item.id))}>Remove</button></article>)}</div><div className="cart-total"><span>Estimated order total</span><strong>{money(cartTotal)}</strong></div><a className="whatsapp full" href={`https://wa.me/?text=${encodeURIComponent(`Hi FazaaPrint, I'd like to order:\n${cart.map((i) => `â€¢ ${i.title} â€” ${money(i.price)}`).join("\n")}\nEstimated total: ${money(cartTotal)}`)}`} target="_blank" rel="noreferrer"><Icon name="phone" /> Send order on WhatsApp</a><p className="estimate-note">FazaaPrint will confirm availability, files and the final price before printing.</p></>}</aside></div>}
    </main>
  );
}


