import SiteHeader from "./components/SiteHeader";

export default function Home() {
  return <main>
    <SiteHeader />
    <section className="hero home-hero">
      <div className="hero-copy">
        <span className="eyebrow">✦ Printing made simple in the Maldives</span>
        <h1>Your ideas.<br /><em>Beautifully</em> printed.</h1>
        <p>Easy document printing, study-ready past papers and professional finishing—prepared with care by FazaaPrint.</p>
        <div className="hero-actions"><a className="primary-button" href="/order">Start a print order <span>→</span></a><a className="text-button" href="/services">View prices</a></div>
        <div className="trust-row"><span>✓ Clear pricing</span><span>✓ Private file analysis</span><span>✓ Friendly local service</span></div>
      </div>
      <div className="hero-art" aria-label="Colorful FazaaPrint paper stack"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="paper-stack"><div className="paper back" /><div className="paper middle" /><div className="paper front"><span>FAZAA</span><strong>PRINT</strong><small>Make it memorable.</small><div className="swatches"><i /><i /><i /></div></div></div><div className="floating-card price"><small>B&W from</small><strong>MVR 2</strong><span>per printed side</span></div></div>
    </section>
    <section className="home-choices">
      <a href="/order"><span>01</span><div><small>Upload & calculate</small><h2>Print a document</h2><p>Choose B&W or color, upload your file and see an instant estimate.</p></div><b>→</b></a>
      <a href="/past-papers"><span>02</span><div><small>Study ready</small><h2>Order past papers</h2><p>Browse English, Economics, Chemistry, Biology and custom packs.</p></div><b>→</b></a>
      <a href="/services"><span>03</span><div><small>Finishing touches</small><h2>Explore services</h2><p>Binding, scanning, laminating, covers and more with clear prices.</p></div><b>→</b></a>
    </section>
    <section className="home-cta"><div><span className="eyebrow">Fast and straightforward</span><h2>Know what you need?</h2><p>Build your order on a focused page without distractions.</p></div><a className="primary-button" href="/order">Open ordering platform <span>→</span></a></section>
    <footer><a className="brand logo-brand" href="/"><img src="/fazaaprint-logo.png" alt="FazaaPrint" /></a><p>Made for bright ideas and busy students.</p><span>© 2026 FazaaPrint · Maldives</span></footer>
  </main>;
}
